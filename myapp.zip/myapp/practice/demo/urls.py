# this file helps to view the html in web page
from django.conf.urls import url
from . import views

# Create your views here.
# calling the html file, using url, to webpage

urlpatterns= [
    url(r'^$', views.index, name= 'index'),
    ]
