from django.contrib import admin
# we gonna import the models file
from .models import Post

# Register your models here.
# here we gonna view the models which we have included in models.py

admin.site.register(Post)
